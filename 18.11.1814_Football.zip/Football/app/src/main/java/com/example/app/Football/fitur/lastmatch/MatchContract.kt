package com.example.app.Football.fitur.lastmatch

import com.example.app.Football.entity.Event

interface MatchContract {
    interface View{
        fun hideLoading()
        fun showLoading()
        fun displayFootballMatch(matchList:List<Event>)
    }

    interface Presenter{
        fun getFootballMatchData(leagueName: String = "4328")
        fun onDestroyPresenter()

    }
}