package com.example.app.Football.fitur.favmatch


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.example.app.Football.R
import com.example.app.Football.adapter.ClubAdapter
import com.example.app.Football.entity.Event
import com.example.app.Football.entity.repository.LocalRepositorympl
import com.example.app.Football.entity.repository.MatchRepositorympl
import com.example.app.Football.ekstensi.hide
import com.example.app.Football.ekstensi.show
import com.example.app.Football.rest.BallApi
import com.example.app.Football.rest.BallRest
import com.example.app.Football.content.AppSchedulerProvider
import kotlinx.android.synthetic.main.fragment_favorite_match.*

class FavMatchFragment : Fragment(), FavMatchContract.View {
    private var matchLists : MutableList<Event> = mutableListOf()
    lateinit var mPresenter : FavMatchPresenter

    override fun hideLoading() {
        mainProgressBar.hide()
        rvFootball.visibility = View.VISIBLE
    }

    override fun showLoading() {
        mainProgressBar.show()
        rvFootball.visibility = View.INVISIBLE
    }

    override fun displayFootballMatch(matchList: List<Event>) {
        matchLists.clear()
        matchLists.addAll(matchList)
        val layoutManager = LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false)
        rvFootball.layoutManager = layoutManager
        rvFootball.adapter = ClubAdapter(matchList, context)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        val service = BallApi.getClient().create(BallRest::class.java)
        val request = MatchRepositorympl(service)
        val localRepositoryImpl = LocalRepositorympl(context!!)
        val scheduler = AppSchedulerProvider()
        mPresenter = FavMatchPresenter(this, request, localRepositoryImpl, scheduler)
        mPresenter.getFootballMatchData()

        swiperefreshFav.setOnRefreshListener {
            mPresenter.getFootballMatchData()
        }

    }

    override fun hideSwipeRefresh() {
        swiperefreshFav.isRefreshing = false
        mainProgressBar.hide()
        rvFootball.visibility = View.VISIBLE
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_favorite_match, container, false)
    }

    override fun onDestroy() {
        super.onDestroy()
        mPresenter.onDestroyPresenter()
    }


}
