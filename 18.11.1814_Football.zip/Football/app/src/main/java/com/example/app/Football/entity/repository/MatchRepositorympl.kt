package com.example.app.Football.entity.repository

import com.example.app.Football.entity.FootballMatch
import com.example.app.Football.rest.BallRest
import io.reactivex.Flowable

class MatchRepositorympl(private val ballRest: BallRest) : MatchRepository {

    override fun searchMatches(query: String?) = ballRest.searchMatches(query)

    override fun getEventById(id: String): Flowable<FootballMatch> = ballRest.getEventById(id)

    override fun getUpcomingMatch(id: String): Flowable<FootballMatch> = ballRest.getUpcomingMatch(id)

    override fun getFootballMatch(id: String): Flowable<FootballMatch> = ballRest.getLastmatch(id)
}