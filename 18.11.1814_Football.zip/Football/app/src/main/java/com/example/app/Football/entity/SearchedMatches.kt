package com.example.app.Football.entity

import com.google.gson.annotations.SerializedName

data class SearchedMatches(
        @SerializedName("event") var events: List<Event>
)