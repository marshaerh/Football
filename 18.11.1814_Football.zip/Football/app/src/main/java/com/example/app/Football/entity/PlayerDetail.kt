package com.example.app.Football.entity

import com.google.gson.annotations.SerializedName

data class PlayerDetail(
        @SerializedName("players")
        var player: List<Player>)