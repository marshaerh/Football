package com.example.app.Football.entity.repository

import com.example.app.Football.entity.db.FavMatch
import com.example.app.Football.entity.db.FavTeam

interface LocalRepository {

    fun getMatchFromDb() : List<FavMatch>

    fun insertData(eventId: String, homeId: String, awayId: String)

    fun deleteData(eventId: String)

    fun checkFavorite(eventId: String) : List<FavMatch>

    fun getTeamFromDb() : List<FavTeam>

    fun insertTeamData(teamId: String, imgUrl: String)

    fun deleteTeamData(teamId: String)

    fun checkFavTeam(teamId: String) : List<FavTeam>
}