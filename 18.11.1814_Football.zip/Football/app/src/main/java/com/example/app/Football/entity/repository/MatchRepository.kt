package com.example.app.Football.entity.repository

import com.example.app.Football.entity.FootballMatch
import com.example.app.Football.entity.SearchedMatches
import io.reactivex.Flowable

interface MatchRepository {

    fun getFootballMatch(id : String) : Flowable<FootballMatch>

    fun getEventById(id: String) : Flowable<FootballMatch>

    fun searchMatches(query: String?) : Flowable<SearchedMatches>
    fun getUpcomingMatch(id: String): Flowable<FootballMatch>
}