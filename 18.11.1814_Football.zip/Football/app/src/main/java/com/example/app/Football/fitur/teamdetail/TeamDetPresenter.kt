package com.example.app.Football.fitur.teamdetail

import com.example.app.Football.entity.repository.LocalRepositorympl

class TeamDetPresenter(val mView: TeamDetContract.View,
                       val localRepositorympl: LocalRepositorympl): TeamDetContract.Presenter {


    override fun deleteTeam(id: String) {
        localRepositorympl.deleteTeamData(id)
    }

    override fun checkTeam(id: String) {
        mView.setFavoriteState(localRepositorympl.checkFavTeam(id))
    }

    override fun insertTeam(id: String, imgUrl: String) {
        localRepositorympl.insertTeamData(id, imgUrl)
    }


}