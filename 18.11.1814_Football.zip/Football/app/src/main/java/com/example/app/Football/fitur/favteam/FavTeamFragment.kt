package com.example.app.Football.fitur.favteam


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.GridLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.example.app.Football.R
import com.example.app.Football.adapter.TeamAdapter
import com.example.app.Football.entity.Team
import com.example.app.Football.entity.repository.LocalRepositorympl
import com.example.app.Football.entity.repository.TeamRepositorympl
import com.example.app.Football.ekstensi.hide
import com.example.app.Football.ekstensi.show
import com.example.app.Football.rest.BallApi
import com.example.app.Football.rest.BallRest
import com.example.app.Football.content.AppSchedulerProvider
import kotlinx.android.synthetic.main.fragment_favorite_team.*

class FavTeamFragment : Fragment(), FavTeamContract.View {

    private var teamLists : MutableList<Team> = mutableListOf()
    lateinit var mPresenter : FavTeamPresenter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {

        return inflater.inflate(R.layout.fragment_favorite_team, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        val sercive = BallApi.getClient().create(BallRest::class.java)
        val localRepositoryImpl = LocalRepositorympl(context!!)
        val teamRepositoryImpl = TeamRepositorympl(sercive)
        val scheduler = AppSchedulerProvider()
        mPresenter = FavTeamPresenter(this, localRepositoryImpl, teamRepositoryImpl, scheduler)
        mPresenter.getTeamData()

        swiperefresh.setOnRefreshListener {
            mPresenter.getTeamData()
        }
    }

    override fun displayTeams(teamList: List<Team>) {
        teamLists.clear()
        teamLists.addAll(teamList)
        val layoutManager = GridLayoutManager(context, 3)
        rvTeam.layoutManager = layoutManager
        rvTeam.adapter = TeamAdapter(teamLists, context)
    }

    override fun hideLoading() {
        mainProgressBar.hide()
        rvTeam.visibility = View.VISIBLE
    }

    override fun showLoading() {
        mainProgressBar.show()
        rvTeam.visibility = View.GONE
    }

    override fun hideSwipeRefresh() {
        swiperefresh.isRefreshing = false
        mainProgressBar.hide()
        rvTeam.visibility = View.VISIBLE
    }

    override fun onDestroy() {
        super.onDestroy()
        mPresenter.onDestroy()
    }


}
