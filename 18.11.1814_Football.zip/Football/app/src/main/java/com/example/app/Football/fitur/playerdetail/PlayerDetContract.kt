package com.example.app.Football.fitur.playerdetail

import com.example.app.Football.entity.Player

interface PlayerDetContract {

    interface View{
        fun displayPlayerDetail(player: Player)
    }
    interface Presenter{
        fun getPlayerData(idPlayer: String)
        fun onDestroy()
    }
}