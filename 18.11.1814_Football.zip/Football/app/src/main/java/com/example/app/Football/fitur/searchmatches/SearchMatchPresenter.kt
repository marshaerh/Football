package com.example.app.Football.fitur.searchmatches

import com.example.app.Football.entity.SearchedMatches
import com.example.app.Football.entity.repository.MatchRepositorympl
import com.example.app.Football.content.SchedulerProvider
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.subscribers.ResourceSubscriber
import java.util.*

class SearchMatchPresenter(val mView: SearchMatchContract.View,
                           val matchRepositorympl: MatchRepositorympl,
                           val schedulerProvider: SchedulerProvider): SearchMatchContract.Presenter {

    val compositeDisposable = CompositeDisposable()

    override fun searchMatch(query: String?) {
        mView.showLoading()
        compositeDisposable.add(matchRepositorympl.searchMatches(query)
                .subscribeOn(schedulerProvider.io())
                .observeOn(schedulerProvider.ui())
                .subscribeWith(object: ResourceSubscriber<SearchedMatches>(){
                    override fun onComplete() {
                        mView.hideLoading()
                    }

                    override fun onNext(t: SearchedMatches) {
                        mView.displayMatch(t.events ?: Collections.emptyList())
                    }

                    override fun onError(t: Throwable?) {
                        mView.displayMatch(Collections.emptyList())
                        mView.hideLoading()
                    }

                })
        )
    }

    override fun onDestroy() {
        compositeDisposable.dispose()
    }

}