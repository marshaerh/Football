package com.example.app.Football.entity.repository

import com.example.app.Football.entity.FootballPlayer
import com.example.app.Football.entity.PlayerDetail
import io.reactivex.Flowable

interface PlayerRepository {

    fun getAllPlayers(teamId: String?) : Flowable<FootballPlayer>

    fun getPlayerDetail(playerId: String?) : Flowable<PlayerDetail>
}