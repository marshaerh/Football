package com.example.app.Football.fitur.favmatch

import com.example.app.Football.entity.Event
import com.example.app.Football.entity.FootballMatch
import com.example.app.Football.entity.repository.LocalRepositorympl
import com.example.app.Football.entity.repository.MatchRepositorympl
import com.example.app.Football.content.SchedulerProvider
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.subscribers.ResourceSubscriber
import java.util.*

class FavMatchPresenter(val mView: FavMatchContract.View,
                        val matchRepositorympl: MatchRepositorympl,
                        val localRepositorympl: LocalRepositorympl,
                        val scheduler: SchedulerProvider) : FavMatchContract.Presenter{

    val compositeDisposable = CompositeDisposable()

    override fun getFootballMatchData() {
        mView.showLoading()
        val favList = localRepositorympl.getMatchFromDb()
        var eventList: MutableList<Event> = mutableListOf()
        for (fav in favList){
            compositeDisposable.add(matchRepositorympl.getEventById(fav.idEvent)
                    .observeOn(scheduler.ui())
                    .subscribeOn(scheduler.io())
                    .subscribeWith(object: ResourceSubscriber<FootballMatch>(){
                        override fun onComplete() {
                            mView.hideLoading()
                            mView.hideSwipeRefresh()
                        }

                        override fun onNext(t: FootballMatch) {
                            eventList.add(t.events[0])
                            mView.displayFootballMatch(eventList)
                        }

                        override fun onError(t: Throwable?) {
                            mView.displayFootballMatch(Collections.emptyList())
                            mView.hideLoading()
                            mView.hideSwipeRefresh()
                        }

                    })
            )
        }

        if(favList.isEmpty()){
            mView.hideLoading()
            mView.hideSwipeRefresh()
            mView.displayFootballMatch(eventList)
        }
    }

    override fun onDestroyPresenter() {
        compositeDisposable.dispose()
    }
}