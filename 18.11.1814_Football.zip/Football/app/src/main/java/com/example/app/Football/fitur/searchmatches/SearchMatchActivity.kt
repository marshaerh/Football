package com.example.app.Football.fitur.searchmatches

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.SearchView
import android.util.Log
import android.view.Menu
import com.example.app.Football.R
import com.example.app.Football.adapter.ClubAdapter
import com.example.app.Football.entity.Event
import com.example.app.Football.entity.repository.MatchRepositorympl
import com.example.app.Football.ekstensi.hide
import com.example.app.Football.ekstensi.show
import com.example.app.Football.rest.BallApi
import com.example.app.Football.rest.BallRest
import com.example.app.Football.content.AppSchedulerProvider
import kotlinx.android.synthetic.main.activity_search_match.*

class SearchMatchActivity : AppCompatActivity(), SearchMatchContract.View {

    private var matchLists : MutableList<Event> = mutableListOf()
    lateinit var mPresenter: SearchMatchContract.Presenter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search_match)

        val query = intent.getStringExtra("query")
        Log.v("test", query)
        val service = BallApi.getClient().create(BallRest::class.java)
        val request = MatchRepositorympl(service)
        val scheduler = AppSchedulerProvider()
        mPresenter = SearchMatchPresenter(this, request, scheduler)
        mPresenter.searchMatch(query)

    }

    override fun showLoading() {
        mainProgressBar.show()
        rvFootball.hide()
    }

    override fun hideLoading() {
        mainProgressBar.hide()
        rvFootball.show()
    }

    override fun displayMatch(matchList: List<Event>) {
        matchLists.clear()
        matchLists.addAll(matchList)
        val layoutManager = LinearLayoutManager(applicationContext, LinearLayoutManager.VERTICAL, false)
        rvFootball.layoutManager = layoutManager
        rvFootball.adapter = ClubAdapter(matchList, applicationContext)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_search, menu)
        val searchView = menu?.findItem(R.id.actionSearch)?.actionView as SearchView?
        searchView?.queryHint = "Search Matches"

        searchView?.setOnQueryTextListener(object: SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(query: String?): Boolean {

                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                mPresenter.searchMatch(newText)
                return false
            }
        })

        return true
    }

}