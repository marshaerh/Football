package com.example.app.Football.adapter

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.app.Football.R
import com.example.app.Football.entity.Event
import com.example.app.Football.fitur.detail.DetActivity
import com.example.app.Football.content.DateHelper
//import kotlinx.android.synthetic.main.activity_detail.view.*
import org.jetbrains.anko.startActivity


class ClubAdapter(val eventList: List<Event>,
                  val context: Context?) :
        RecyclerView.Adapter<ClubAdapter.ClubViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):
            ClubViewHolder {

        return ClubViewHolder(LayoutInflater.from(context).inflate(R.layout.item_teams, parent, false))
    }

    override fun getItemCount(): Int = eventList.size

    override fun onBindViewHolder(holder: ClubViewHolder,
                                  position: Int) {

        holder.bind(eventList[position])
    }

    inner class ClubViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        fun bind(event: Event) {

            itemView.setOnClickListener {

                itemView.context.startActivity<DetActivity>("match" to event)
            }
        }
    }

}