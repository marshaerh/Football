package com.example.app.Football.fitur.players


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.GridLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.example.app.Football.R
import com.example.app.Football.adapter.PlayerAdapter
import com.example.app.Football.entity.Player
import com.example.app.Football.entity.Team
import com.example.app.Football.entity.repository.PlayerRepositorympl
import com.example.app.Football.ekstensi.hide
import com.example.app.Football.ekstensi.show
import com.example.app.Football.rest.BallApi
import com.example.app.Football.rest.BallRest
import com.example.app.Football.content.AppSchedulerProvider
import kotlinx.android.synthetic.main.fragment_players.*

class PlayersFragment : Fragment(), PlayersContract.View {

    private var listPlayer : MutableList<Player> = mutableListOf()
    lateinit var mPresenter: PlayersContract.Presenter

    override fun showLoading() {
        playerProgressbar.show()
        rvPlayer.visibility = View.GONE
    }

    override fun hideLoading() {
        playerProgressbar.hide()
        rvPlayer.visibility = View.VISIBLE
    }

    override fun displayPlayers(playerList: List<Player>) {
        listPlayer.clear()
        listPlayer.addAll(playerList)
        val layoutManager = GridLayoutManager(context, 3)
        rvPlayer.layoutManager = layoutManager
        rvPlayer.adapter = PlayerAdapter(listPlayer, context)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_players, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        val team: Team? = arguments?.getParcelable("teams")
        val service = BallApi.getClient().create(BallRest::class.java)
        val request = PlayerRepositorympl(service)
        val scheduler = AppSchedulerProvider()
        mPresenter = PlayersPresenter(this, request, scheduler)
        mPresenter.getAllPlayer(team?.idTeam)

    }

    override fun onDestroy() {
        super.onDestroy()
        mPresenter.onDestroy()
    }

}
