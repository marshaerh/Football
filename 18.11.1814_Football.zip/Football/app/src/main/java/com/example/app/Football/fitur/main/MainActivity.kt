package com.example.app.Football.fitur.main

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.example.app.Football.R
import com.example.app.Football.fitur.FavoriteFragment
import com.example.app.Football.fitur.MatchesFragment
import com.example.app.Football.fitur.teams.TeamsFragment
import kotlinx.android.synthetic.main.bottom_nav_view.*
import kotlinx.android.synthetic.main.home_activity.*

class MainActivity : AppCompatActivity(), MainContract.View{



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.home_activity)

        setSupportActionBar(toolbar_main)

        bottom_navigation.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {

                R.id.upMatch -> {
                    loadUpcomingMatch(savedInstanceState)
                }
                R.id.favMatch -> {
                    loadFavoritesMatch(savedInstanceState)
                }
            }
            true
        }
        bottom_navigation.selectedItemId = R.id.upMatch


    }

    private fun setOnClickListener(function: () -> Unit) {

    }



    private fun loadMatch(savedInstanceState: Bundle?) {
        if (savedInstanceState == null) {
            supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.main_container,
                            MatchesFragment(),
                            MatchesFragment::class.java.simpleName)
                    .commit()
        }
    }

    private fun loadUpcomingMatch(savedInstanceState: Bundle?) {
        if (savedInstanceState == null) {
            supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.main_container,
                            TeamsFragment(),
                            TeamsFragment::class.java.simpleName)
                    .commit()
        }
    }

    private fun loadFavoritesMatch(savedInstanceState: Bundle?) {
        if (savedInstanceState == null) {
            supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.main_container,
                            FavoriteFragment(),
                            FavoriteFragment::class.java.simpleName)
                    .commit()
        }
    }
}
