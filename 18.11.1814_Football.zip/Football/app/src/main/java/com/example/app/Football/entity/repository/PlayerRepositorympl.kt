package com.example.app.Football.entity.repository

import com.example.app.Football.rest.BallRest

class PlayerRepositorympl(private val ballRest: BallRest): PlayerRepository {

    override fun getAllPlayers(teamId: String?) = ballRest.getAllPlayers(teamId)

    override fun getPlayerDetail(playerId: String?) = ballRest.getPlayerDetail(playerId)
}