package com.example.app.Football.fitur.lastmatch

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter

import com.example.app.Football.R
import com.example.app.Football.adapter.ClubAdapter
import com.example.app.Football.entity.Event
import com.example.app.Football.entity.repository.MatchRepositorympl
import com.example.app.Football.ekstensi.hide
import com.example.app.Football.ekstensi.show
import com.example.app.Football.rest.BallApi
import com.example.app.Football.rest.BallRest
import com.example.app.Football.content.AppSchedulerProvider
import kotlinx.android.synthetic.main.fragment_teams.*
import kotlinx.android.synthetic.main.fragment_upcoming_match.*
import kotlinx.android.synthetic.main.fragment_upcoming_match.mainProgressBar


class LastMatchFragment : Fragment(), MatchContract.View {

    lateinit var mPresenter : LastMatchPresenter
    lateinit var leagueName : String

    private var matchLists : MutableList<Event> = mutableListOf()

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        val service = BallApi.getClient().create(BallRest::class.java)
        val request = MatchRepositorympl(service)
        val scheduler = AppSchedulerProvider()
        mPresenter = LastMatchPresenter(this, request, scheduler)
        mPresenter.getFootballMatchData()
        val spinnerItems = resources.getStringArray(R.array.leagueArray)
        val spinnerAdapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, spinnerItems)
        spinnerMatch.adapter = spinnerAdapter

    }
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.item_teams, container, false)
    }

    override fun hideLoading() {
        mainProgressBar.hide()
        rvTeam.visibility = View.VISIBLE
    }

    override fun showLoading() {
        mainProgressBar.show()
        rvTeam.visibility = View.INVISIBLE
    }

    override fun displayFootballMatch(matchList: List<Event>) {
        matchLists.clear()
        matchLists.addAll(matchList)
        val layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        rvTeam.layoutManager = layoutManager
        rvTeam.adapter = ClubAdapter(matchList, context)
    }
    override fun onDestroy() {
        super.onDestroy()
        mPresenter.onDestroyPresenter()
    }

}
