package com.example.app.Football.fitur.players

import com.example.app.Football.entity.Player

interface PlayersContract {

    interface View{
        fun showLoading()
        fun hideLoading()
        fun displayPlayers(playerList: List<Player>)

    }
    interface Presenter{
        fun getAllPlayer(teamId: String?)
        fun onDestroy()
    }

}