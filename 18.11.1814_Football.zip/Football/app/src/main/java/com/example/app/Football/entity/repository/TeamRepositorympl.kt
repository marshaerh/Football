package com.example.app.Football.entity.repository

import com.example.app.Football.entity.Teams
import com.example.app.Football.rest.BallRest
import io.reactivex.Flowable

class TeamRepositorympl(val ballRest: BallRest) : TeamRepository{

    override fun getAllTeam(id: String) = ballRest.getAllTeam(id)

    override fun getTeamBySearch(query: String) = ballRest.getTeamBySearch(query)

    override fun getTeams(id: String): Flowable<Teams> = ballRest.getAllTeam(id)

    override fun getTeamsDetail(id: String): Flowable<Teams> = ballRest.getTeam(id)

}