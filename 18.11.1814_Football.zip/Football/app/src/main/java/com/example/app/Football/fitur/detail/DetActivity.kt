package com.example.app.Football.fitur.detail

import android.os.Build
import android.os.Bundle
import android.support.annotation.RequiresApi
import android.support.v4.content.ContextCompat
import android.support.v7.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import com.example.app.Football.R
import com.example.app.Football.entity.Event
import com.example.app.Football.entity.Team
import com.example.app.Football.entity.db.FavMatch
import com.example.app.Football.entity.repository.LocalRepositorympl
import com.example.app.Football.entity.repository.TeamRepositorympl
import com.example.app.Football.rest.BallApi
import com.example.app.Football.rest.BallRest
//import kotlinx.android.synthetic.main.activity_detail.*
//import kotlinx.android.synthetic.main.activity_detail.awayNameTv
//import kotlinx.android.synthetic.main.activity_detail.awayScoreTv
//import kotlinx.android.synthetic.main.activity_detail.dateScheduleTv
//import kotlinx.android.synthetic.main.activity_detail.homeNameTv
//import kotlinx.android.synthetic.main.activity_detail.homeScoreTv
import kotlinx.android.synthetic.main.item_teams.*
import org.jetbrains.anko.toast

class DetActivity : AppCompatActivity(), DetContract.View {

    private var CHANNEL_ID="Your_Channel_ID";

    private var isFavorite: Boolean = false
    private var menuItem: Menu? = null

    lateinit var event: Event


    lateinit var mPresenter: DetPresenter

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.item_teams)
        val service = BallApi.getClient().create(BallRest::class.java)
        val request = TeamRepositorympl(service)
        val localRepo = LocalRepositorympl(applicationContext)
        mPresenter = DetPresenter(this, request, localRepo)

        event = intent.getParcelableExtra("match")
        mPresenter.getTeamsBadgeAway(event.idAwayTeam)
        mPresenter.getTeamsBadgeHome(event.idHomeTeam)
        mPresenter.checkMatch(event.idEvent)
        initData(event)
        supportActionBar?.title = event.strEvent


    }

    @RequiresApi(Build.VERSION_CODES.M)
    fun initData(event: Event) {
        if (event.intHomeScore == null) {
            tvTeam.setTextColor(applicationContext.getColor(R.color.upcoming_match))
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        menuItem = menu
        setFavorite()
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            R.id.favorite -> {
                if (!isFavorite) {
                    mPresenter.insertMatch(
                            event.idEvent, event.idHomeTeam, event.idAwayTeam)
                    toast("success")
                    isFavorite = !isFavorite
                } else {
                    mPresenter.deleteMatch(event.idEvent)
                    toast("removed")
                    isFavorite = !isFavorite
                }
                setFavorite()
                true
            }

            else -> super.onOptionsItemSelected(item)
        }

    }

    private fun setFavorite() {
        if (isFavorite)
            menuItem?.getItem(0)?.icon = ContextCompat.getDrawable(this, R.drawable.ic_added_fav_24dp)
        else
            menuItem?.getItem(0)?.icon = ContextCompat.getDrawable(this, R.drawable.ic_add_fav_24dp)
    }

    override fun displayTeamBadgeHome(team: Team) {

    }

    override fun displayTeamBadgeAway(team: Team) {

    }

    override fun setFavoriteState(favList: List<FavMatch>) {
        if (!favList.isEmpty()) isFavorite = true
    }

    override fun onDestroy() {
        super.onDestroy()
        mPresenter.onDestroyPresenter()
    }

}