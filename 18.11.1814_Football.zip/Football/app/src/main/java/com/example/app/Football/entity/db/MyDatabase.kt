package com.example.app.Football.entity.db

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import org.jetbrains.anko.db.*

class MyDatabaseOpenHelper(ctx: Context) : ManagedSQLiteOpenHelper(ctx, "Fav.db", null, 1) {

    companion object {

        private var instance: MyDatabaseOpenHelper? = null

        @Synchronized
        fun getInstance(ctx: Context): MyDatabaseOpenHelper {
            if (instance == null) {
                instance = MyDatabaseOpenHelper(ctx.applicationContext)
            }
            return instance as MyDatabaseOpenHelper
        }
    }

    override fun onCreate(p0: SQLiteDatabase) {

        p0.createTable(FavMatch.TABLE_FAVORITE, true,
                FavMatch.ID to INTEGER + PRIMARY_KEY + AUTOINCREMENT,
                FavMatch.EVENT_ID to TEXT + UNIQUE,
                FavMatch.HOME_TEAM_ID to TEXT,
                FavMatch.AWAY_TEAM_ID to TEXT)

        p0.createTable(FavTeam.TEAM_TABLE, true,
                FavTeam.ID to INTEGER + PRIMARY_KEY + AUTOINCREMENT,
                FavTeam.TEAM_ID to TEXT,
                FavTeam.TEAM_IMAGE to TEXT)
    }

    override fun onUpgrade(p0: SQLiteDatabase, p1: Int, p2: Int) {

        p0.dropTable(FavMatch.TABLE_FAVORITE, true)
        p0.dropTable(FavTeam.TEAM_TABLE, true)
    }
}

val Context.database: MyDatabaseOpenHelper
    get() = MyDatabaseOpenHelper.getInstance(applicationContext)