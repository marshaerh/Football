package com.example.app.Football.entity.repository

import android.content.Context
import com.example.app.Football.entity.db.FavMatch
import com.example.app.Football.entity.db.FavTeam
import com.example.app.Football.entity.db.database
import org.jetbrains.anko.db.classParser
import org.jetbrains.anko.db.insert
import org.jetbrains.anko.db.select
import org.jetbrains.anko.db.delete

class LocalRepositorympl(private val context: Context) : LocalRepository {

    override fun getTeamFromDb(): List<FavTeam> {

        lateinit var favoriteList :List<FavTeam>

        context.database.use {

            val result = select(FavTeam.TEAM_TABLE)
            val favorite = result.parseList(classParser<FavTeam>())
            favoriteList = favorite
        }

        return favoriteList
    }

    override fun insertTeamData(teamId: String, imgUrl: String) {

        context.database.use {
            insert(FavTeam.TEAM_TABLE,
                    FavTeam.TEAM_ID to teamId,
                        FavTeam.TEAM_IMAGE to imgUrl)

        }

    }
    override fun deleteTeamData(teamId: String) {

        context.database.use{
            delete(FavTeam.TEAM_TABLE, "(TEAM_ID = {id})",
                    "id" to teamId)
        }
    }

    override fun checkFavTeam(teamId: String): List<FavTeam> {

        return context.database.use {

            val result = select(FavTeam.TEAM_TABLE)
                    .whereArgs("(TEAM_ID = {id})",
                            "id" to teamId)

            val favorite = result.parseList(classParser<FavTeam>())
            favorite
        }
    }

    override fun checkFavorite(eventId: String): List<FavMatch> {

        return context.database.use {

            val result = select(FavMatch.TABLE_FAVORITE)
                    .whereArgs("(EVENT_ID = {id})",
                            "id" to eventId)

            val favorite = result.parseList(classParser<FavMatch>())
            favorite
        }
    }


    override fun deleteData(eventId: String) {

        context.database.use{

            delete(FavMatch.TABLE_FAVORITE, "(EVENT_ID = {id})",
                        "id" to eventId)
        }
    }

    override fun insertData(eventId: String, homeId: String, awayId: String) {

        context.database.use {

            insert(FavMatch.TABLE_FAVORITE,
                    FavMatch.EVENT_ID to eventId,
                    FavMatch.HOME_TEAM_ID to homeId,
                    FavMatch.AWAY_TEAM_ID to awayId)
        }
    }

    override fun getMatchFromDb(): List<FavMatch> {

        lateinit var favoriteList :List<FavMatch>

        context.database.use {

            val result = select(FavMatch.TABLE_FAVORITE)
            val favorite = result.parseList(classParser<FavMatch>())
            favoriteList = favorite
        }

        return favoriteList
    }
}