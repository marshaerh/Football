package com.example.app.Football.fitur.teamdetail

import com.example.app.Football.entity.db.FavTeam

interface TeamDetContract {

    interface View{
        fun setFavoriteState(favList:List<FavTeam>)
    }

    interface Presenter{
        fun deleteTeam(id:String)
        fun checkTeam(id:String)
        fun insertTeam(id: String, imgUrl: String)
    }
}