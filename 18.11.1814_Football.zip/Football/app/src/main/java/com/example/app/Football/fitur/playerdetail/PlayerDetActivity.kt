package com.example.app.Football.fitur.playerdetail

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.app.Football.R
import com.example.app.Football.entity.Player
import com.example.app.Football.entity.repository.PlayerRepositorympl
import com.example.app.Football.rest.BallApi
import com.example.app.Football.rest.BallRest
import com.example.app.Football.content.AppSchedulerProvider
import kotlinx.android.synthetic.main.activity_player_detail.*
import kotlinx.android.synthetic.main.player_layout_detail.*

class PlayerDetActivity : AppCompatActivity(), PlayerDetContract.View {

    lateinit var player: Player
    lateinit var mPresenter: PlayerDetContract.Presenter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player_detail)
        setSupportActionBar(toolbar)
        player = intent.getParcelableExtra("player")
        supportActionBar?.title = player.strPlayer
        val service = BallApi.getClient().create(BallRest::class.java)
        val request = PlayerRepositorympl(service)
        val scheduler = AppSchedulerProvider()
        mPresenter = PlayerDetPresenter(this, request, scheduler)
        mPresenter.getPlayerData(player.idPlayer)
    }

    override fun displayPlayerDetail(player: Player) {
        initView(player)
    }

    override fun onDestroy() {
        super.onDestroy()
        mPresenter.onDestroy()
    }

    private fun initView(player: Player){

        loadBanner(player)
        Glide.with(applicationContext)
                .load(player.strCutout)
                .into(imgPlayer)

        playerName.text = player.strPlayer
        tvPosition.text = player.strPosition
        tvDate.text = player.dateBorn
        playerOverview.text = player.strDescriptionEN
    }

    private fun loadBanner(player: Player){
        if(!player.strFanart1.equals(null)){
            Glide.with(applicationContext)
                    .load(player.strFanart1)
                    .into(imageBannerPlayer)
        }else{
            Glide.with(applicationContext)
                    .load(player.strThumb)
                    .into(imageBannerPlayer)
        }
    }
}
