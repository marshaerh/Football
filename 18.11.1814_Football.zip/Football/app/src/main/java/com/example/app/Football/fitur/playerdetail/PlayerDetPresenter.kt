package com.example.app.Football.fitur.playerdetail

import com.example.app.Football.entity.PlayerDetail
import com.example.app.Football.entity.repository.PlayerRepositorympl
import com.example.app.Football.content.SchedulerProvider
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.subscribers.ResourceSubscriber

class PlayerDetPresenter(val mView: PlayerDetContract.View,
                         val playersRepositorympl: PlayerRepositorympl,
                         val schedulerProvider: SchedulerProvider): PlayerDetContract.Presenter {


    val compositeDisposable = CompositeDisposable()

    override fun getPlayerData(idPlayer: String) {
        compositeDisposable.add(playersRepositorympl.getPlayerDetail(idPlayer)
                .subscribeOn(schedulerProvider.io())
                .observeOn(schedulerProvider.ui())
                .subscribeWith(object: ResourceSubscriber<PlayerDetail>(){
                    override fun onComplete() {

                    }

                    override fun onNext(t: PlayerDetail) {
                        mView.displayPlayerDetail(t.player[0])
                    }

                    override fun onError(t: Throwable?) {

                    }

                })
        )
    }

    override fun onDestroy() {
        compositeDisposable.dispose()
    }
}