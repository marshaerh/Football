package com.example.app.Football.fitur.searchmatches

import com.example.app.Football.entity.Event

interface SearchMatchContract {

    interface View{
        fun showLoading()
        fun hideLoading()
        fun displayMatch(matchList: List<Event>)
    }
    interface Presenter{
        fun searchMatch(query: String?)
        fun onDestroy()
    }

}