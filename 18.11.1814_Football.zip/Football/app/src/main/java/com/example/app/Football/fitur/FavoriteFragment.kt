package com.example.app.Football.fitur

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.os.Bundle
import android.support.design.widget.TabLayout
import android.support.v4.app.Fragment
import android.support.v4.view.ViewPager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.example.app.Football.R
import com.example.app.Football.adapter.ViewPagerAdapter
import com.example.app.Football.fitur.favmatch.FavMatchFragment
import com.example.app.Football.fitur.favteam.FavTeamFragment

class FavoriteFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {

        return inflater.inflate(R.layout.fragment_favorite, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val vPager = view.findViewById<ViewPager>(R.id.viewpager)
        val tabs = view.findViewById<TabLayout>(R.id.tabs)
        val adapter = ViewPagerAdapter(childFragmentManager)
        adapter.populateFragment(FavMatchFragment(), "Match")
        adapter.populateFragment(FavTeamFragment(), "Team")
        vPager.adapter = adapter
        tabs.setupWithViewPager(vPager)
    }
}
