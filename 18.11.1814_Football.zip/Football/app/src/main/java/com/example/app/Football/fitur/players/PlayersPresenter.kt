package com.example.app.Football.fitur.players

import com.example.app.Football.entity.FootballPlayer
import com.example.app.Football.entity.repository.PlayerRepositorympl
import com.example.app.Football.content.SchedulerProvider
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.subscribers.ResourceSubscriber
import java.util.*

class PlayersPresenter(val mView: PlayersContract.View,
                       val playersRepositorympl: PlayerRepositorympl,
                       val schedulerProvider: SchedulerProvider): PlayersContract.Presenter {

    val compositeDisposable = CompositeDisposable()

    override fun getAllPlayer(teamId: String?) {
        mView.showLoading()
        compositeDisposable.add(playersRepositorympl.getAllPlayers(teamId)
                .subscribeOn(schedulerProvider.io())
                .observeOn(schedulerProvider.ui())
                .subscribeWith(object: ResourceSubscriber<FootballPlayer>(){
                    override fun onComplete() {
                        mView.hideLoading()
                    }

                    override fun onNext(t: FootballPlayer) {
                        mView.displayPlayers(t.player)
                    }

                    override fun onError(t: Throwable?) {
                        mView.displayPlayers(Collections.emptyList())
                        mView.hideLoading()
                    }

                })
        )
    }
    override fun onDestroy() {
        compositeDisposable.dispose()
    }
}