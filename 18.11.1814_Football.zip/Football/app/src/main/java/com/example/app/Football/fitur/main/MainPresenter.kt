package com.example.app.Football.fitur.main

import com.example.app.Football.entity.repository.MatchRepositorympl
import io.reactivex.disposables.CompositeDisposable

class MainPresenter(val mView : MainContract.View,
                    val matchRepositorympl: MatchRepositorympl) :
        MainContract.Presenter{

    val compositeDisposable = CompositeDisposable()
}