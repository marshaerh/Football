package com.example.app.Football.fitur.detail

import com.example.app.Football.entity.Teams
import com.example.app.Football.entity.repository.LocalRepositorympl
import com.example.app.Football.entity.repository.TeamRepositorympl
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import io.reactivex.subscribers.ResourceSubscriber

class DetPresenter(val mView : DetContract.View, val teamRepositorympl: TeamRepositorympl,
                   val localRepositorympl: LocalRepositorympl) : DetContract.Presenter {
    override fun deleteMatch(id: String) {
        localRepositorympl.deleteData(id)
    }

    override fun checkMatch(id: String) {
        mView.setFavoriteState(localRepositorympl.checkFavorite(id))
    }

    override fun insertMatch(eventId: String, homeId: String, awayId: String) {
        localRepositorympl.insertData(eventId, homeId, awayId)
    }

    override fun getTeamsBadgeHome(id: String) {
        compositeDisposable.add(teamRepositorympl.getTeamsDetail(id)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribeWith(object: ResourceSubscriber<Teams>(){
                    override fun onComplete() {

                    }

                    override fun onNext(t: Teams) {
                        mView.displayTeamBadgeHome(t.teams[0])
                    }

                    override fun onError(t: Throwable?) {

                    }
                })
        )
    }

    val compositeDisposable = CompositeDisposable()

    override fun getTeamsBadgeAway(id:String) {
        compositeDisposable.add(teamRepositorympl.getTeamsDetail(id)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribeWith(object: ResourceSubscriber<Teams>(){
                    override fun onComplete() {

                    }

                    override fun onNext(t: Teams) {
                        mView.displayTeamBadgeHome(t.teams[0])
                    }

                    override fun onError(t: Throwable?) {

                    }
                })
        )
    }

    override fun onDestroyPresenter() {
        compositeDisposable.dispose()
    }
}