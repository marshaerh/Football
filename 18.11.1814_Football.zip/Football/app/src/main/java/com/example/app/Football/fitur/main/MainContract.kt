package com.example.app.Football.fitur.main

interface MainContract {

    interface View{
    }

    interface Presenter{

    }

}