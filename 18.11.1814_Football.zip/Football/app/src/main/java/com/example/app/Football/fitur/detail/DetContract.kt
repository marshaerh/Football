package com.example.app.Football.fitur.detail

import com.example.app.Football.entity.Team
import com.example.app.Football.entity.db.FavMatch

interface DetContract {

    interface View{
        fun displayTeamBadgeHome(team: Team)
        fun displayTeamBadgeAway(team: Team)
        fun setFavoriteState(favList:List<FavMatch>)
    }

    interface Presenter{
        fun getTeamsBadgeAway(id:String)
        fun getTeamsBadgeHome(id:String)
        fun deleteMatch(id:String)
        fun checkMatch(id:String)
        fun insertMatch(eventId: String, homeId: String, awayId: String)
        fun onDestroyPresenter()
    }
}