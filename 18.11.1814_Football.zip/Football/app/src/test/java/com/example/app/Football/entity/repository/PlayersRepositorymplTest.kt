package com.example.app.Football.entity.repository

import com.example.app.Football.rest.BallRest
import org.junit.Before
import org.junit.Test

import org.mockito.Mock
import org.mockito.Mockito.verify
import org.mockito.MockitoAnnotations

class PlayersRepositorymplTest {

    @Mock
    lateinit var ballRest: BallRest

    lateinit var playersRepositoryImpl: PlayerRepositorympl


    @Before
    fun setUp() {
        MockitoAnnotations.initMocks(this)
        playersRepositoryImpl = PlayerRepositorympl(ballRest)
    }

    @Test
    fun getAllPlayers() {
        playersRepositoryImpl.getAllPlayers("123")
        verify(ballRest).getAllPlayers("123")
    }

    @Test
    fun getPlayerDetail() {
        playersRepositoryImpl.getPlayerDetail("123")
        verify(ballRest).getPlayerDetail("123")
    }
}