package com.example.app.Football.entity.repository

import com.example.app.Football.rest.BallRest
import org.junit.Test

import org.junit.Before
import org.mockito.Mock
import org.mockito.Mockito.verify
import org.mockito.MockitoAnnotations

class MatchRepositorymplTest {

    @Mock
    lateinit var ballRest: BallRest

    lateinit var matchRepositoryImpl: MatchRepositorympl

    @Before
    fun setUp() {
        MockitoAnnotations.initMocks(this)
        matchRepositoryImpl = MatchRepositorympl(ballRest)
    }

    @Test
    fun getEventById() {
        matchRepositoryImpl.getEventById("123")
        verify(ballRest).getEventById("123")
    }

    @Test
    fun getFootballMatch() {
        matchRepositoryImpl.getFootballMatch("123")
        verify(ballRest).getLastmatch("123")
    }
}