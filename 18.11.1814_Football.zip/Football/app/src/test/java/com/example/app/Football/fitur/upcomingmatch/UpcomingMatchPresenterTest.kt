package com.example.app.Football.fitur.upcomingmatch

import com.example.app.Football.entity.Event
import com.example.app.Football.entity.FootballMatch
import com.example.app.Football.entity.repository.MatchRepositorympl
import com.example.app.Football.fitur.lastmatch.MatchContract
import com.example.app.Football.content.SchedulerProvider
import com.example.app.Football.content.TestSchedulerProvider
import io.reactivex.Flowable
import org.junit.Test

import org.junit.Before
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.MockitoAnnotations

class UpcomingMatchPresenterTest {

    @Mock
    lateinit var mView: MatchContract.View

    @Mock
    lateinit var matchRepositoryImpl: MatchRepositorympl

    lateinit var scheduler: SchedulerProvider

    lateinit var mPresenter: UpcomingMatchPresenter

    enum class UpcomingMatchPresenter {
        ;

        fun getFootballMatchData() {
            TODO("Not yet implemented")
        }

    }

    lateinit var match : FootballMatch

    lateinit var footballMatch: Flowable<FootballMatch>

    private val event = mutableListOf<Event>()

    @Before
    fun setUp() {
        MockitoAnnotations.initMocks(this)
        scheduler = TestSchedulerProvider()
        match = FootballMatch(event)
        footballMatch = Flowable.just(match)
        mPresenter = UpcomingMatchPresenter(mView, matchRepositoryImpl, scheduler as TestSchedulerProvider)
        Mockito.`when`(matchRepositoryImpl.getUpcomingMatch("4328")).thenReturn(footballMatch)
    }

    private fun UpcomingMatchPresenter(mView: MatchContract.View,
                                       matchRepositoryImpl: MatchRepositorympl,
                                       scheduler: TestSchedulerProvider): UpcomingMatchPresenter {

    }

    @Test
    fun getFootballMatchData() {
        mPresenter.getFootballMatchData()
        Mockito.verify(mView).showLoading()
        Mockito.verify(mView).displayFootballMatch(event)
        Mockito.verify(mView).hideLoading()
    }
}
