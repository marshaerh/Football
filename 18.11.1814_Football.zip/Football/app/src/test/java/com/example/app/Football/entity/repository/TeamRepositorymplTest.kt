package com.example.app.Football.entity.repository

import com.example.app.Football.rest.BallRest
import org.junit.Test

import org.junit.Before
import org.mockito.Mock
import org.mockito.Mockito.verify
import org.mockito.MockitoAnnotations

class TeamRepositorymplTest {


    @Mock
    lateinit var ballRest: BallRest

    lateinit var teamRepositoryImpl: TeamRepositorympl

    @Before
    fun setUp() {
        MockitoAnnotations.initMocks(this)
        teamRepositoryImpl = TeamRepositorympl(ballRest)
    }

    @Test
    fun getTeamBySearch() {
        teamRepositoryImpl.getTeamBySearch("query")
        verify(ballRest).getTeamBySearch("query")
    }

    @Test
    fun getTeams() {
        teamRepositoryImpl.getTeams("123")
        verify(ballRest).getAllTeam("123")
    }

    @Test
    fun getTeamsDetail() {
        teamRepositoryImpl.getTeamsDetail("id")
        verify(ballRest).getTeam("id")
    }

    @Test
    fun getAllTeam(){
        teamRepositoryImpl.getAllTeam("id")
        verify(ballRest).getAllTeam("id")
    }
}