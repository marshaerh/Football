package com.example.app.Football.fitur.players

import com.example.app.Football.entity.*
import com.example.app.Football.entity.repository.PlayerRepositorympl
import com.example.app.Football.content.SchedulerProvider
import com.example.app.Football.content.TestSchedulerProvider
import io.reactivex.Flowable
import org.junit.Test

import org.junit.Before
import org.mockito.Mock
import org.mockito.Mockito.`when`
import org.mockito.Mockito.verify
import org.mockito.MockitoAnnotations

class PlayersPresenterTest {

    @Mock
    lateinit var mView: PlayersContract.View

    @Mock
    lateinit var playersRepositoryImpl: PlayerRepositorympl

    lateinit var scheduler: SchedulerProvider

    lateinit var mPresenter: PlayersPresenter

    lateinit var player : FootballPlayer

    lateinit var playersDetail: Flowable<FootballPlayer>

    private val playerList = mutableListOf<Player>()

    @Before
    fun setUp() {
        MockitoAnnotations.initMocks(this)
        scheduler = TestSchedulerProvider()
        player = FootballPlayer(playerList)
        playersDetail = Flowable.just(player)
        mPresenter = PlayersPresenter(mView, playersRepositoryImpl, scheduler)
        `when`(playersRepositoryImpl.getAllPlayers("123")).thenReturn(playersDetail)

    }

    @Test
    fun getAllPlayer() {
        mPresenter.getAllPlayer("123")
        verify(mView).showLoading()
        verify(mView).displayPlayers(playerList)
        verify(mView).hideLoading()
    }
}